# Copyright (c) OpenMMLab. All rights reserved.
import mmcv
import numpy as np
import torch
import cv2
from mmdet.models import BaseDetector

from mmrotate.core import imshow_det_rbboxes
from ..builder import ROTATED_DETECTORS


@ROTATED_DETECTORS.register_module()
class RotatedBaseDetector(BaseDetector):
    """Base class for rotated detectors."""

    def __init__(self, init_cfg=None):
        super(RotatedBaseDetector, self).__init__(init_cfg)
        self.fp16_enabled = False

    def show_result(self,
                    img,
                    result,
                    gt_bboxes=None,
                    gt_labels=None,
                    score_thr=0.3,
                    bbox_color=(72, 101, 241),
                    text_color=(72, 101, 241),
                    mask_color=None,
                    thickness=2,
                    font_size=13,
                    win_name='',
                    show=False,
                    wait_time=0,
                    out_file=None,
                    **kwargs):
        """Draw `result` over `img`.

        Args:
            img (str or Tensor): The image to be displayed.
            result (Tensor or tuple): The results to draw over `img`
                bbox_result or (bbox_result, segm_result).
            score_thr (float, optional): Minimum score of bboxes to be shown.
                Default: 0.3.
            bbox_color (str or tuple(int) or :obj:`Color`):Color of bbox lines.
               The tuple of color should be in BGR order. Default: 'green'
            text_color (str or tuple(int) or :obj:`Color`):Color of texts.
               The tuple of color should be in BGR order. Default: 'green'
            mask_color (None or str or tuple(int) or :obj:`Color`):
               Color of masks. The tuple of color should be in BGR order.
               Default: None
            thickness (int): Thickness of lines. Default: 2
            font_size (int): Font size of texts. Default: 13
            win_name (str): The window name. Default: ''
            wait_time (float): Value of waitKey param.
                Default: 0.
            show (bool): Whether to show the image.
                Default: False.
            out_file (str or None): The filename to write the image.
                Default: None.

        Returns:
            img (torch.Tensor): Only if not `show` or `out_file`
        """
        img = mmcv.imread(img)
        img = img.copy()
        if isinstance(result, tuple):
            bbox_result, segm_result = result
            if isinstance(segm_result, tuple):
                segm_result = segm_result[0]
        else:
            bbox_result, segm_result = result, None
        bboxes = np.vstack(bbox_result)

        # 这里的bboxes好像已经是xywhθ+score的形式了
        labels = [
            np.full(bbox.shape[0], i, dtype=np.int32)
            for i, bbox in enumerate(bbox_result)
        ]
        labels = np.concatenate(labels)
        # draw segmentation masks
        segms = None
        if segm_result is not None and len(labels) > 0:  # non empty
            segms = mmcv.concat_list(segm_result)
            if isinstance(segms[0], torch.Tensor):
                segms = torch.stack(segms, dim=0).detach().cpu().numpy()
            else:
                segms = np.stack(segms, axis=0)
        # if out_file specified, do not show image in window
        if out_file is not None:
            show = False
        # draw bounding boxes
        img = imshow_det_rbboxes(
            img,
            bboxes,
            labels,
            gt_bboxes,
            gt_labels,
            segms,
            class_names=self.CLASSES,
            score_thr=score_thr,
            bbox_color=bbox_color,
            text_color=text_color,
            mask_color=mask_color,
            thickness=thickness,
            font_size=font_size,
            win_name=win_name,
            show=show,
            wait_time=wait_time,
            out_file=out_file)

        if not (show or out_file):
            return img

    def show_multi_thresh(self,
                    img,
                    result,
                    gt_bboxes=None,
                    gt_labels=None,
                    score_thrs=[0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1],
                    bbox_color=(72, 101, 241),
                    text_color=(72, 101, 241),
                    mask_color=None,
                    thickness=2,
                    font_size=13,
                    win_name='',
                    show=False,
                    wait_time=0,
                    out_file=None,
                    **kwargs):

        img = mmcv.imread(img)
        img = img.copy()
        if isinstance(result, tuple):
            bbox_result, segm_result = result
            if isinstance(segm_result, tuple):
                segm_result = segm_result[0]
        else:
            bbox_result, segm_result = result, None
        bboxes = np.vstack(bbox_result)
        labels = [
            np.full(bbox.shape[0], i, dtype=np.int32)
            for i, bbox in enumerate(bbox_result)
        ]
        labels = np.concatenate(labels)
        segms = None
        if segm_result is not None and len(labels) > 0:  # non empty
            segms = mmcv.concat_list(segm_result)
            if isinstance(segms[0], torch.Tensor):
                segms = torch.stack(segms, dim=0).detach().cpu().numpy()
            else:
                segms = np.stack(segms, axis=0)

        for score_thr in score_thrs:
            out_file_thr = f"{out_file[:-4]}_{str(int(score_thr*10))}.jpg" if out_file else None
            img_thr = imshow_det_rbboxes(
                img,
                bboxes,
                labels,
                gt_bboxes,
                gt_labels,
                segms,
                class_names=self.CLASSES,
                score_thr=score_thr,
                bbox_color=bbox_color,
                text_color=text_color,
                mask_color=mask_color,
                thickness=thickness,
                font_size=font_size,
                win_name=win_name,
                show=show,
                wait_time=wait_time,
                out_file=out_file_thr)

            if not (show or out_file_thr):
                return img_thr

    def draw_dotted_line(self, img, pt1, pt2, color, thickness=1, style='dotted', gap=10):
        cv2.circle(img, pt1, 3, color, 3)
        cv2.circle(img, pt2, 3, color, 3)

        dist = ((pt2[0] - pt1[0]) ** 2 + (pt2[1] - pt1[1]) ** 2) ** .5
        pts = []
        for i in np.arange(0, dist, gap):
            r = i / dist
            x = int((pt1[0] * (1 - r) + pt2[0] * r) + .5)
            y = int((pt1[1] * (1 - r) + pt2[1] * r) + .5)
            p = (x, y)
            pts.append(p)
        if style == 'dotted':
            for p in pts:
                cv2.circle(img, p, thickness, color, -1)
        else:
            e = pts[0]
            i = 0
            for p in pts:
                s = e
                e = p
                if i % 2 == 1:
                    cv2.line(img, s, e, color, thickness)
                i += 1

    def draw_dashed_line(self, image, p1, p2, color, thickness=1, dash_length=5):
        """Draw a dashed line in img between p1 and p2 with given color."""
        dist = ((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2) ** 0.5
        dashes = int(dist / dash_length)
        for idx in range(dashes):
            start = p1 + (p2 - p1) * (idx / dashes)
            end = p1 + (p2 - p1) * ((idx + 1) / dashes)
            if (idx % 2) == 0:
                image = cv2.line(image, tuple(start.astype(np.int32)), tuple(end.astype(np.int32)), color, thickness)
        return image

    def draw_chains_on_frames(self, concatenated_image, chains):
        chain_colors = [tuple(np.random.choice(range(256), size=3).tolist()) for _ in range(len(chains))]
        for chain_idx in range(len(chains)):
            frame_idxs = list(chains[chain_idx].keys())
            boxes = list(chains[chain_idx].values())
            for i in range(len(frame_idxs)-1):
                # Get the current and next frame indices to draw the line
                curr_frame_idx = frame_idxs[i]
                next_frame_idx = frame_idxs[i+1]
                # print("Curent frame_idx: {}, Next frame idx: {}".format(curr_frame_idx, next_frame_idx))

                box = boxes[i]
                curr_tl = (int(box[0]), int(box[1]))
                next_box = boxes[i + 1]
                next_tl = (int(next_box[0]), int(next_box[1]))

                # Calculate the actual position in the concatenated image
                curr_pos = (curr_frame_idx * concatenated_image.shape[0] + curr_tl[0], curr_tl[1])
                next_pos = (next_frame_idx * concatenated_image.shape[0] + next_tl[0], next_tl[1])
                # Draw the dotted line
                self.draw_dotted_line(concatenated_image, curr_pos, next_pos, chain_colors[chain_idx], thickness=2, style='dotted')

    def show_multiframe(self,
                    multi_frame_imgs,
                    multi_frame_results,
                    chains,
                    score_thr=0.3,
                    bbox_color=(72, 101, 241),
                    text_color=(72, 101, 241),
                    mask_color=None,
                    thickness=2,
                    font_size=13,
                    win_name='',
                    show=False,
                    wait_time=0,
                    out_file=None,
                    **kwargs):
        """Draw `result` over `img`.

        Args:
            img (str or Tensor): The image to be displayed.
            result (Tensor or tuple): The results to draw over `img`
                bbox_result or (bbox_result, segm_result).
            score_thr (float, optional): Minimum score of bboxes to be shown.
                Default: 0.3.
            bbox_color (str or tuple(int) or :obj:`Color`):Color of bbox lines.
               The tuple of color should be in BGR order. Default: 'green'
            text_color (str or tuple(int) or :obj:`Color`):Color of texts.
               The tuple of color should be in BGR order. Default: 'green'
            mask_color (None or str or tuple(int) or :obj:`Color`):
               Color of masks. The tuple of color should be in BGR order.
               Default: None
            thickness (int): Thickness of lines. Default: 2
            font_size (int): Font size of texts. Default: 13
            win_name (str): The window name. Default: ''
            wait_time (float): Value of waitKey param.
                Default: 0.
            show (bool): Whether to show the image.
                Default: False.
            out_file (str or None): The filename to write the image.
                Default: None.

        Returns:
            img (torch.Tensor): Only if not `show` or `out_file`
        """
        concatenated_image = []
        print(chains)
        for img, result in zip(multi_frame_imgs, multi_frame_results):
            img = mmcv.imread(img)
            img = img.copy()
            if isinstance(result, tuple):
                bbox_result, segm_result = result
                if isinstance(segm_result, tuple):
                    segm_result = segm_result[0]
            else:
                bbox_result, segm_result = result[0], None
            bboxes = np.vstack(bbox_result)

            # 这里的bboxes好像已经是xywhθ+score的形式了
            labels = [
                np.full(bbox.shape[0], i, dtype=np.int32)
                for i, bbox in enumerate(bbox_result)
            ]
            labels = np.concatenate(labels)
            # draw segmentation masks
            segms = None
            if segm_result is not None and len(labels) > 0:  # non empty
                segms = mmcv.concat_list(segm_result)
                if isinstance(segms[0], torch.Tensor):
                    segms = torch.stack(segms, dim=0).detach().cpu().numpy()
                else:
                    segms = np.stack(segms, axis=0)
            # if out_file specified, do not show image in window
            if out_file is not None:
                show = False
            # draw bounding boxes
            img = imshow_det_rbboxes(
                img,
                bboxes,
                labels,
                segms,
                class_names=self.CLASSES,
                score_thr=score_thr,
                bbox_color=bbox_color,
                text_color=text_color,
                mask_color=mask_color,
                thickness=thickness,
                font_size=font_size,
                win_name=win_name,
                show=show,
                wait_time=wait_time,
                out_file=out_file)
            concatenated_image.append(img)

        concatenated_image = np.concatenate(concatenated_image, axis=1)
        cv2.rectangle(concatenated_image, (2560, 0), (3072, 512), color=(0, 255, 255), thickness=2)

        # Draw chains on the concatenated image
        self.draw_chains_on_frames(concatenated_image, chains)

        if out_file is not None:
            mmcv.imwrite(concatenated_image, out_file)

        if not (show or out_file):
            return concatenated_image
