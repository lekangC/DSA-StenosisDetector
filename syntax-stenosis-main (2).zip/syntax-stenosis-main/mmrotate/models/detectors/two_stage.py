# Copyright (c) OpenMMLab. All rights reserved.
import os.path
import warnings
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.runner import load_checkpoint
from mmcv.cnn.bricks.transformer import (BaseTransformerLayer,
                                         TransformerLayerSequence,
                                         build_transformer_layer_sequence,
                                         build_positional_encoding)
from ..builder import ROTATED_DETECTORS, build_backbone, build_head, build_neck
from .base import RotatedBaseDetector
from ..utils import build_PoolNet, build_cascade_poolnet
import numpy as np
import cv2
from PIL import Image
import time


class conv_block(nn.Module):
    def __init__(self, ch_in, ch_out):
        super(conv_block, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(ch_in, ch_out, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(ch_out),
            nn.ReLU(inplace=True),
            nn.Conv2d(ch_out, ch_out, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(ch_out),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        x = self.conv(x)
        return x


class up_conv(nn.Module):
    def __init__(self, ch_in, ch_out):
        super(up_conv, self).__init__()
        self.up = nn.Sequential(
            nn.Upsample(scale_factor=2),
            nn.Conv2d(ch_in, ch_out, kernel_size=3, stride=1, padding=1, bias=True),
            nn.BatchNorm2d(ch_out),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        x = self.up(x)
        return x


class U_Net(nn.Module):
    def __init__(self, img_ch=3, output_ch=1):
        super(U_Net, self).__init__()

        self.Maxpool = nn.MaxPool2d(kernel_size=2, stride=2)

        self.Conv1 = conv_block(ch_in=img_ch, ch_out=64)
        self.Conv2 = conv_block(ch_in=64, ch_out=128)
        self.Conv3 = conv_block(ch_in=128, ch_out=256)
        self.Conv4 = conv_block(ch_in=256, ch_out=512)
        self.Conv5 = conv_block(ch_in=512, ch_out=1024)

        self.Up5 = up_conv(ch_in=1024, ch_out=512)
        self.Up_conv5 = conv_block(ch_in=1024, ch_out=512)

        self.Up4 = up_conv(ch_in=512, ch_out=256)
        self.Up_conv4 = conv_block(ch_in=512, ch_out=256)

        self.Up3 = up_conv(ch_in=256, ch_out=128)
        self.Up_conv3 = conv_block(ch_in=256, ch_out=128)

        self.Up2 = up_conv(ch_in=128, ch_out=64)
        self.Up_conv2 = conv_block(ch_in=128, ch_out=64)

        self.Conv_1x1 = nn.Conv2d(64, output_ch, kernel_size=1, stride=1, padding=0)

        self.nllLoss = nn.NLLLoss(None, True)

    def loss(self, pred, gt):
        ce_loss = self.nllLoss(torch.log(pred), gt)
        return dict(segment_loss=ce_loss)

    def forward(self, x):
        # encoding path
        x1 = self.Conv1(x)

        x2 = self.Maxpool(x1)
        x2 = self.Conv2(x2)

        x3 = self.Maxpool(x2)
        x3 = self.Conv3(x3)

        x4 = self.Maxpool(x3)
        x4 = self.Conv4(x4)

        x5 = self.Maxpool(x4)
        x5 = self.Conv5(x5)

        # decoding + concat path
        d5 = self.Up5(x5)
        d5 = torch.cat((x4, d5), dim=1)

        d5 = self.Up_conv5(d5)

        d4 = self.Up4(d5)
        d4 = torch.cat((x3, d4), dim=1)
        d4 = self.Up_conv4(d4)

        d3 = self.Up3(d4)
        d3 = torch.cat((x2, d3), dim=1)
        d3 = self.Up_conv3(d3)

        d2 = self.Up2(d3)
        d2 = torch.cat((x1, d2), dim=1)
        d2 = self.Up_conv2(d2)

        d1 = self.Conv_1x1(d2)
        d1 = F.softmax(d1, dim=1)  # mine

        return d1


@ROTATED_DETECTORS.register_module()
class RotatedTwoStageDetector(RotatedBaseDetector):
    """Base class for rotated two-stage detectors.

    Two-stage detectors typically consisting of a region proposal network and a
    task-specific regression head.
    """

    def __init__(self,
                 percept_lvl,
                 backbone,
                 neck=None,
                 rpn_head=None,
                 roi_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 init_cfg=None):
        super(RotatedTwoStageDetector, self).__init__(init_cfg)
        if pretrained:
            warnings.warn('DeprecationWarning: pretrained is deprecated, '
                          'please use "init_cfg" instead')
            backbone.pretrained = pretrained
        self.percept_lvl = percept_lvl
        self.backbone = build_backbone(backbone)

        if self.percept_lvl['num_level'] == "Two":
            self.segment = U_Net(img_ch=1, output_ch=2)
        elif self.percept_lvl['num_level'] == "Three":
            self.segment = build_PoolNet()
            self.segment = build_cascade_poolnet()
        else:
            self.segment = None

        if neck is not None:
            self.neck = build_neck(neck)

        if rpn_head is not None:
            rpn_train_cfg = train_cfg.rpn if train_cfg is not None else None
            rpn_head_ = rpn_head.copy()
            rpn_head_.update(train_cfg=rpn_train_cfg, test_cfg=test_cfg.rpn)
            self.rpn_head = build_head(rpn_head_)

        if roi_head is not None:
            # update train and test cfg here for now
            # TODO: refactor assigner & sampler
            rcnn_train_cfg = train_cfg.rcnn if train_cfg is not None else None
            roi_head.update(train_cfg=rcnn_train_cfg)
            roi_head.update(test_cfg=test_cfg.rcnn)
            roi_head.pretrained = pretrained
            self.roi_head = build_head(roi_head)

        self.train_cfg = train_cfg
        self.test_cfg = test_cfg

    @property
    def with_rpn(self):
        """bool: whether the detector has RPN"""
        return hasattr(self, 'rpn_head') and self.rpn_head is not None

    @property
    def with_roi_head(self):
        """bool: whether the detector has a RoI head"""
        return hasattr(self, 'roi_head') and self.roi_head is not None

    def extract_feat(self, img):
        """Directly extract features from the backbone+neck."""
        x = self.backbone(img)
        # for i in range(len(x)):
        #     print(x[i].shape)
        if self.with_neck:
            x = self.neck(x)
        return x

    def forward_dummy(self, img):
        """Used for computing network flops.

        See `mmdetection/tools/analysis_tools/get_flops.py`
        """
        outs = ()
        # backbone
        x = self.extract_feat(img)
        # rpn
        if self.with_rpn:
            rpn_outs = self.rpn_head(x)
            outs = outs + (rpn_outs,)
        proposals = torch.randn(1000, 5).to(img.device)
        # roi_head
        roi_outs = self.roi_head.forward_dummy(x, proposals)
        outs = outs + (roi_outs,)
        return outs

    def forward_train(self,
                      img,
                      img_metas,
                      gt_bboxes,
                      gt_labels,
                      gt_bboxes_ignore=None,
                      gt_masks=None,
                      proposals=None,
                      **kwargs):
        """
        Args:
            img (Tensor): of shape (N, C, H, W) encoding input images.
                Typically these should be mean centered and std scaled.

            img_metas (list[dict]): list of image info dict where each dict
                has: 'img_shape', 'scale_factor', 'flip', and may also contain
                'filename', 'ori_shape', 'pad_shape', and 'img_norm_cfg'.
                For details on the values of these keys see
                `mmdet/datasets/pipelines/formatting.py:Collect`.

            gt_bboxes (list[Tensor]): Ground truth bboxes for each image with
                shape (num_gts, 5) in [cx, cy, w, h, a] format.

            gt_labels (list[Tensor]): class indices corresponding to each box

            gt_bboxes_ignore (None | list[Tensor]): specify which bounding
                boxes can be ignored when computing the loss.

            gt_masks (None | Tensor) : true segmentation masks for each box
                used if the architecture supports a segmentation task.

            proposals : override rpn proposals with custom proposals. Use when
                `with_rpn` is False.

        Returns:
            dict[str, Tensor]: a dictionary of loss components
        """
        losses = dict()

        # dsa_image = img[:, 0, :, :].unsqueeze(1).repeat(1, 3, 1, 1)
        dsa_image = img[:, 0, :, :].unsqueeze(1)
        # show_image = Image.fromarray(dsa_image[0, 0].cpu().numpy()*255)
        # show_image.show()
        if self.percept_lvl['num_level'] != "One":
            gt_full_vessel = img[:, 1, :, :]
            gt_full_vessel = torch.where(gt_full_vessel > 0, torch.tensor(1).cuda(), torch.tensor(0).cuda())
            gt_stenosis_mask = img[:, -1, :, :]
            gt_stenosis_mask = torch.where(gt_stenosis_mask > 0, torch.tensor(1).cuda(), torch.tensor(0).cuda())
            # show_im = gt_full_vessel[0].cpu().numpy().astype(np.uint8) * 255
            # pil_image = Image.fromarray(show_im)
            # pil_image.show()

        if self.percept_lvl['num_level'] == "Two":
            pred_fullVessel = self.segment(dsa_image)
            full_vessel_loss = self.segment.loss(pred_fullVessel, gt_full_vessel)
            losses.update(full_vessel_loss)
            input = torch.cat((dsa_image.repeat(1,2,1,1),
                               pred_fullVessel[:, 1, :, :].unsqueeze(1)), dim=1)
        elif self.percept_lvl['num_level'] == "Three":
            pred_fullVessel, pred_stenosis = self.segment(dsa_image)

            full_vessel_loss = self.segment.full_vessel_loss(pred_fullVessel, gt_full_vessel)
            full_vessel_loss['full_vessel_loss'] *= 0.5
            losses.update(full_vessel_loss)

            stenosis_loss = self.segment.stenosis_loss(pred_stenosis, gt_stenosis_mask)
            # stenosis_loss['stenosis_loss'] *= 2
            losses.update(stenosis_loss)

            input = torch.cat((img[:, 0, :, :].unsqueeze(1),
                               pred_fullVessel[:, 1, :, :].unsqueeze(1),
                              pred_stenosis[:, 1, :, :].unsqueeze(1)), dim=1)
        else:
            input = dsa_image.repeat(1, 3, 1, 1)

        x = self.extract_feat(input)

        # RPN forward and loss
        if self.with_rpn:
            proposal_cfg = self.train_cfg.get('rpn_proposal',
                                              self.test_cfg.rpn)
            rpn_losses, proposal_list = self.rpn_head.forward_train(
                x,
                img_metas,
                gt_bboxes,
                gt_labels=None,
                gt_bboxes_ignore=gt_bboxes_ignore,
                proposal_cfg=proposal_cfg,
                **kwargs)
            # 默认情况下，proposal_list 长度为4，每个都为[2000, 6]大小的tensor
            losses.update(rpn_losses)
        else:
            proposal_list = proposals

        roi_losses = self.roi_head.forward_train(x, img_metas, proposal_list,
                                                 gt_bboxes, gt_labels,
                                                 gt_bboxes_ignore, gt_masks,
                                                 **kwargs)
        losses.update(roi_losses)
        return losses

    async def async_simple_test(self,
                                img,
                                img_meta,
                                proposals=None,
                                rescale=False):
        """Async test without augmentation."""
        assert self.with_bbox, 'Bbox head must be implemented.'
        x = self.extract_feat(img)

        if proposals is None:
            proposal_list = await self.rpn_head.async_simple_test_rpn(
                x, img_meta)
        else:
            proposal_list = proposals

        return await self.roi_head.async_simple_test(
            x, proposal_list, img_meta, rescale=rescale)

    def show_segmentation(self, pred_mask, filename):
        pred_mask = pred_mask[0, 1, :, :].cpu()
        pred_mask = np.asarray(pred_mask)
        pred_mask = (pred_mask * 255).astype(np.uint8)
        pred_mask = Image.fromarray(pred_mask)
        # pred_mask.show()
        pred_mask.save(os.path.join('work_dirs/threeLevel/result_train/stenosis_segment', filename))

    def simple_test(self, img, img_metas, proposals=None, rescale=False, multiframe=False):
        if not multiframe:
            return self.simple_test_singleframe(img, img_metas, proposals, rescale)
        else:
            return self.simple_test_multiframe(img, img_metas, proposals, rescale)

    def simple_test_singleframe(self, img, img_metas, proposals=None, rescale=False):
        """Test without augmentation."""
        assert self.with_bbox, 'Bbox head must be implemented.'
        # dsa_image = img[:, 0, :, :].unsqueeze(1).repeat(1, 3, 1, 1)
        dsa_image = img[:, 0, :, :].unsqueeze(1)
        # print(img_metas)

        if self.percept_lvl['num_level'] == "Two":
            pred_fullVessel = self.segment(dsa_image)
            input = torch.cat((dsa_image.repeat(1,2,1,1),
                               pred_fullVessel[:, 1, :, :].unsqueeze(1)), dim=1)
        elif self.percept_lvl['num_level'] == "Three":
            pred_fullVessel, pred_stenosis = self.segment(dsa_image)
            input = torch.cat((dsa_image,
                               pred_fullVessel[:, 1, :, :].unsqueeze(1),
                               pred_stenosis[:, 1, :, :].unsqueeze(1)), dim=1)
        else:
            input = dsa_image.repeat(1, 3, 1, 1)

        x = self.extract_feat(input)

        if proposals is None:
            proposal_list = self.rpn_head.simple_test_rpn(x, img_metas)
        else:
            proposal_list = proposals

        result = self.roi_head.simple_test(
            x, proposal_list, img_metas, rescale=rescale)

        return result

    def aug_test(self, imgs, img_metas, rescale=False):
        """Test with augmentations.

        If rescale is False, then returned bboxes and masks will fit the scale
        of imgs[0].
        """
        x = self.extract_feats(imgs)
        proposal_list = self.rpn_head.aug_test_rpn(x, img_metas)
        return self.roi_head.aug_test(
            x, proposal_list, img_metas, rescale=rescale)

    @staticmethod
    def rotated_to_horizontal_box(x, y, w, h, a):
        import math
        # angle = math.radians(a)
        cos_a = math.cos(a)
        sin_a = abs(math.sin(a))
        new_hori = w * cos_a + h * sin_a
        new_ver = w * sin_a + h * cos_a
        if new_hori > new_ver:
            new_w = new_hori
            new_h = new_ver
            new_a = 0
        else:
            new_w = new_ver
            new_h = new_hori
            new_a = math.radians(-90)
        return (x, y, new_hori, new_ver, new_a)

    def multiframe_r2hbboxes(self, multiframe_results):
        num_frames = len(multiframe_results)
        multiframe_horizontal_results = []
        for frame in range(num_frames):
            cur_frame_results = multiframe_results[frame][0][0]
            hboxes = []
            for i in range(cur_frame_results.shape[0]):
                x, y, w, h, a, _ = cur_frame_results[i]
                # x,y,w,h,a = self.rotated_to_horizontal_box(x,y,w,h,a)
                hboxes.append([x, y, w, h, a, cur_frame_results[i][-1]])
            multiframe_horizontal_results.append(hboxes)
        return multiframe_horizontal_results

    def calculate_iou(self, box1, box2):
        x1, y1, w1, h1, a1, _ = box1
        x1, y1, w1, h1, _ = self.rotated_to_horizontal_box(x1, y1, w1, h1, a1)
        w1 = w1 * 1.5
        h1 = h1 * 1.5
        x2, y2, w2, h2, a2, _ = box2
        x2, y2, w2, h2, _ = self.rotated_to_horizontal_box(x2, y2, w2, h2, a2)
        w2 = w2 * 1.5
        h2 = h2 * 1.5

        xi1 = max(x1, x2)
        yi1 = max(y1, y2)
        xi2 = min(x1 + w1, x2 + w2)
        yi2 = min(y1 + h1, y2 + h2)
        inter_area = max(xi2 - xi1, 0) * max(yi2 - yi1, 0)
        box1_area = w1 * h1
        box2_area = w2 * h2
        union_area = box1_area + box2_area - inter_area
        iou = inter_area / union_area
        return iou

    def track_objectsv3(self, frames, IoUThresh=0.2, lengthThresh=3):
        chains = [{0: box} for box in frames[0]]  # Initialize chains with the first frame boxes as dictionaries
        key_frame_boxes = []

        for i in range(1, len(frames)):
            new_chains = []
            chained = [False for _ in
                       range(len(chains))]  # List to keep track if a chain has been updated in the current frame
            for box in frames[i]:
                max_iou = -1
                max_iou_chain_index = -1
                for j, chain in enumerate(chains):
                    if not chained[j]:  # If the chain has not been updated, check for potential matches
                        latest_frame = max(chain.keys())
                        iou = self.calculate_iou(chain[latest_frame], box)
                        if iou > max_iou:
                            max_iou = iou
                            max_iou_chain_index = j
                if max_iou > IoUThresh:
                    chains[max_iou_chain_index][i] = box  # Update the chain with the new box
                    chained[max_iou_chain_index] = True
                    if i == self.key_frame_idx:
                        key_frame_boxes.append((box, chains[max_iou_chain_index]))
                else:
                    new_chain = {i: box}  # Start a new chain for unmatched boxes
                    new_chains.append(new_chain)
                    if i == self.key_frame_idx:
                        key_frame_boxes.append((box, new_chain))

            chains.extend(new_chains)  # Add new chains to the list of all chains

        # Filter out key frame boxes with chain length less than the threshold
        key_frame_boxes = [box for box, chain in key_frame_boxes if len(chain) >= lengthThresh]

        # Filter out chains with length less than the threshold
        # chains = [chain for chain in chains if len(chain) >= lengthThresh]

        return chains, key_frame_boxes

    def filter_chains(self, chains, Thresh_high=0.7, Thresh_low=0.2):
        # Function to determine if a box should be preserved based on the given conditions
        def should_preserve(chain, frame_idx):
            box = chain.get(frame_idx)
            if not box:
                return False
            confidence = box[5]
            if confidence > Thresh_high:
                return True
            elif Thresh_low < confidence <= Thresh_high:
                return len(chain) > 1  # Check if the chain has more than one box
            return False

        # Filter chains for the 5th frame
        filtered_boxes = [
            chain[5] for chain in chains if should_preserve(chain, 5)
        ]

        result = [[np.array(filtered_boxes)]]
        # Prepare the output format
        # result = [[np.array([box])] for box in filtered_boxes]
        return result

    def simple_test_multiframe(self, img, img_metas, proposals=None, rescale=False):
        """Test without augmentation."""
        assert self.with_bbox, 'Bbox head must be implemented.'
        self.num_frames = img.shape[1]

        self.key_frame_idx = int((self.num_frames - 1) / 2)
        multiframe_results = []

        for frame in range(self.num_frames - 1):
            dsa_image = img[:, frame, :, :].unsqueeze(1)

            if self.percept_lvl['num_level'] == "Two":
                pred_fullVessel = self.segment(dsa_image)
                input = torch.cat((dsa_image.repeat(1, 2, 1, 1),
                                   pred_fullVessel[:, 1, :, :].unsqueeze(1)), dim=1)
            elif self.percept_lvl['num_level'] == "Three":
                pred_fullVessel, pred_stenosis = self.segment(dsa_image)
                input = torch.cat((dsa_image,
                                   pred_fullVessel[:, 1, :, :].unsqueeze(1),
                                   pred_stenosis[:, 1, :, :].unsqueeze(1)), dim=1)
            else:
                input = dsa_image.repeat(1, 3, 1, 1)

            x = self.extract_feat(input)
            if proposals is None:
                proposal_list = self.rpn_head.simple_test_rpn(x, img_metas)
            else:
                proposal_list = proposals
            result = self.roi_head.simple_test(
                x, proposal_list, img_metas, rescale=rescale)
            # print(result)
            # print(result[0][0])
            result = result[0][0]
            result = result[result[:, -1] >= 0.1]
            result = [[result]]
            if frame == self.key_frame_idx:
                key_result = result
            multiframe_results.append(result)

        # print(multiframe_results)
        multiframe_hbboxes = self.multiframe_r2hbboxes(multiframe_results)
        # print(multiframe_hbboxes)

        chains, keyboxes = self.track_objectsv3(multiframe_hbboxes, 0.1, 2)
        filtered_result = self.filter_chains(chains)
        # print("All Boxes: {}".format(key_result))
        # print("Remaining Boxes: {}".format(keyboxes))
        # print(multiframe_results[int(self.num_frames/2)])

        return multiframe_results, chains, filtered_result

@ROTATED_DETECTORS.register_module()
class RotatedMultiFrameDetector(RotatedBaseDetector):
    """Base class for rotated two-stage detectors.

    Two-stage detectors typically consisting of a region proposal network and a
    task-specific regression head.
    """

    def __init__(self,
                 backbone,
                 single_frame_ckpt=None,
                 segment=None,
                 neck=None,
                 encoder=None,
                 positional_encoding=None,
                 rpn_head=None,
                 roi_head=None,
                 train_cfg=None,
                 test_cfg=None,
                 pretrained=None,
                 init_cfg=None):
        super(RotatedMultiFrameDetector, self).__init__(init_cfg)
        if pretrained:
            warnings.warn('DeprecationWarning: pretrained is deprecated, '
                          'please use "init_cfg" instead')
            backbone.pretrained = pretrained
        self.backbone = build_backbone(backbone)

        if segment is not None:
            self.pre_segment = True
            self.segment = U_Net(img_ch=3, output_ch=2)
        else:
            self.pre_segment = False

        if neck is not None:
            self.neck = build_neck(neck)

        if rpn_head is not None:
            rpn_train_cfg = train_cfg.rpn if train_cfg is not None else None
            rpn_head_ = rpn_head.copy()
            rpn_head_.update(train_cfg=rpn_train_cfg, test_cfg=test_cfg.rpn)
            self.rpn_head = build_head(rpn_head_)

        if roi_head is not None:
            # update train and test cfg here for now
            # TODO: refactor assigner & sampler
            rcnn_train_cfg = train_cfg.rcnn if train_cfg is not None else None
            roi_head.update(train_cfg=rcnn_train_cfg)
            roi_head.update(test_cfg=test_cfg.rcnn)
            roi_head.pretrained = pretrained
            self.roi_head = build_head(roi_head)

        self.train_cfg = train_cfg
        self.test_cfg = test_cfg

        self.encoder = build_transformer_layer_sequence(encoder)
        self.positional_encoding = build_positional_encoding(positional_encoding)
        self.level_embeds = nn.Parameter(torch.Tensor(20, self.encoder.embed_dims))

        self.single_frame_ckpt = single_frame_ckpt
        if self.single_frame_ckpt is not None:
            print("Loading Ckpt")
            load_checkpoint(self, single_frame_ckpt, map_location='cpu')
            self.backbone.requires_grad = False
            self.segment.requires_grad = False
            self.neck.requires_grad = False
            self.rpn_head.requires_grad = False

    @property
    def with_rpn(self):
        """bool: whether the detector has RPN"""
        return hasattr(self, 'rpn_head') and self.rpn_head is not None

    @property
    def with_roi_head(self):
        """bool: whether the detector has a RoI head"""
        return hasattr(self, 'roi_head') and self.roi_head is not None

    def extract_feat(self, img):
        """Directly extract features from the backbone+neck."""
        x = self.backbone(img)
        # for i in range(len(x)):
        #     print(x[i].shape)
        if self.with_neck:
            x = self.neck(x)
        return x

    def forward_dummy(self, img):
        """Used for computing network flops.

        See `mmdetection/tools/analysis_tools/get_flops.py`
        """
        outs = ()
        # backbone
        x = self.extract_feat(img)
        # rpn
        if self.with_rpn:
            rpn_outs = self.rpn_head(x)
            outs = outs + (rpn_outs,)
        proposals = torch.randn(1000, 5).to(img.device)
        # roi_head
        roi_outs = self.roi_head.forward_dummy(x, proposals)
        outs = outs + (roi_outs,)
        return outs

    def forward_train_inputfusion(self,
                                  img,
                                  img_metas,
                                  gt_bboxes,
                                  gt_labels,
                                  gt_bboxes_ignore=None,
                                  gt_masks=None,
                                  proposals=None,
                                  **kwargs):
        """
        Args:
            img (Tensor): of shape (N, C, H, W) encoding input images.
                Typically these should be mean centered and std scaled.

            img_metas (list[dict]): list of image info dict where each dict
                has: 'img_shape', 'scale_factor', 'flip', and may also contain
                'filename', 'ori_shape', 'pad_shape', and 'img_norm_cfg'.
                For details on the values of these keys see
                `mmdet/datasets/pipelines/formatting.py:Collect`.

            gt_bboxes (list[Tensor]): Ground truth bboxes for each image with
                shape (num_gts, 5) in [cx, cy, w, h, a] format.

            gt_labels (list[Tensor]): class indices corresponding to each box

            gt_bboxes_ignore (None | list[Tensor]): specify which bounding
                boxes can be ignored when computing the loss.

            gt_masks (None | Tensor) : true segmentation masks for each box
                used if the architecture supports a segmentation task.

            proposals : override rpn proposals with custom proposals. Use when
                `with_rpn` is False.

        Returns:
            dict[str, Tensor]: a dictionary of loss components
        """
        losses = dict()

        dsa_image = img[:, 5, :, :].unsqueeze(1)
        # for i in range(dsa_image.shape[1]):
        #     cur_img = dsa_image[0,i]
        #     print(cur_img)
        #     pil_image = Image.fromarray(cur_img.cpu().numpy()*255)
        #     pil_image.show()

        gt_mask = img[:, -1, :, :]
        gt_mask = torch.where(gt_mask > 0, torch.tensor(1).cuda(), torch.tensor(0).cuda())
        # pil_image = Image.fromarray(gt_mask[0].cpu().numpy().astype(np.uint8)*255)
        # pil_image.show()

        if self.pre_segment:
            masks = []
            num_frame = dsa_image.shape[1]
            for i in range(num_frame):
                cur_frame = dsa_image[:, i, :, :]
                masks.append(cur_frame)
                cur_frame = cur_frame.unsqueeze(1).repeat(1, 3, 1, 1)
                cur_mask = self.segment(cur_frame)
                masks.append(cur_mask[:, 1, :, :])
                if i == int(num_frame / 2):
                    segment_loss = self.segment.loss(cur_mask, gt_mask)
                    segment_loss['segment_loss'] *= 0.5
                    losses.update(segment_loss)
            masks = torch.stack(masks, dim=1)
            input = masks
        else:
            input = dsa_image

        x = self.extract_feat(input)
        # RPN forward and loss
        if self.with_rpn:
            proposal_cfg = self.train_cfg.get('rpn_proposal',
                                              self.test_cfg.rpn)
            rpn_losses, proposal_list = self.rpn_head.forward_train(
                x,
                img_metas,
                gt_bboxes,
                gt_labels=None,
                gt_bboxes_ignore=gt_bboxes_ignore,
                proposal_cfg=proposal_cfg,
                **kwargs)
            # 默认情况下，proposal_list 长度为4，每个都为[2000, 6]大小的tensor
            losses.update(rpn_losses)
        else:
            proposal_list = proposals

        roi_losses = self.roi_head.forward_train(x, img_metas, proposal_list,
                                                 gt_bboxes, gt_labels,
                                                 gt_bboxes_ignore, gt_masks,
                                                 **kwargs)
        losses.update(roi_losses)
        return losses

    def prepare_mask_positional_encoding(self, multilevel_multiframe_feat, img_metas):
        batch_size = multilevel_multiframe_feat[0].size(0)
        input_img_h, input_img_w = 512, 512
        img_masks = multilevel_multiframe_feat[0].new_ones(
            (batch_size, input_img_h, input_img_w))
        for img_id in range(batch_size):
            img_h, img_w, _ = img_metas[img_id]['img_shape']
            img_masks[img_id, :img_h, :img_w] = 0

        mlvl_masks = []
        mlvl_positional_encodings = []
        spatial_shapes = []
        for feat in multilevel_multiframe_feat:
            bs, c, h, w = feat.shape
            spatial_shape = (h, w)
            spatial_shapes.append(spatial_shape)
            mlvl_masks.append(
                F.interpolate(img_masks[None],
                              size=feat.shape[-2:]).to(torch.bool).squeeze(0))
            mlvl_positional_encodings.append(
                self.positional_encoding(mlvl_masks[-1]))
        return mlvl_masks, mlvl_positional_encodings

    @staticmethod
    def get_reference_points(spatial_shapes, valid_ratios, device):
        """Get the reference points used in decoder.

        Args:
            spatial_shapes (Tensor): The shape of all
                feature maps, has shape (num_level, 2).
            valid_ratios (Tensor): The radios of valid
                points on the feature map, has shape
                (bs, num_levels, 2)
            device (obj:`device`): The device where
                reference_points should be.

        Returns:
            Tensor: reference points used in decoder, has \
                shape (bs, num_keys, num_levels, 2).
        """
        reference_points_list = []
        for lvl, (H, W) in enumerate(spatial_shapes):
            #  TODO  check this 0.5
            ref_y, ref_x = torch.meshgrid(
                torch.linspace(
                    0.5, H - 0.5, H, dtype=torch.float32, device=device),
                torch.linspace(
                    0.5, W - 0.5, W, dtype=torch.float32, device=device))
            ref_y = ref_y.reshape(-1)[None] / (
                    valid_ratios[:, None, lvl, 1] * H)
            ref_x = ref_x.reshape(-1)[None] / (
                    valid_ratios[:, None, lvl, 0] * W)
            ref = torch.stack((ref_x, ref_y), -1)
            reference_points_list.append(ref)
        reference_points = torch.cat(reference_points_list, 1)
        reference_points = reference_points[:, :, None] * valid_ratios[:, None]
        return reference_points

    def get_valid_ratio(self, mask):
        """Get the valid radios of feature maps of all  level."""
        _, H, W = mask.shape
        valid_H = torch.sum(~mask[:, :, 0], 1)
        valid_W = torch.sum(~mask[:, 0, :], 1)
        valid_ratio_h = valid_H.float() / H
        valid_ratio_w = valid_W.float() / W
        valid_ratio = torch.stack([valid_ratio_w, valid_ratio_h], -1)
        return valid_ratio

    def get_other_info_for_encoder(self, mlvl_feats, mlvl_masks, mlvl_pos_embeds):
        feat_flatten = []
        mask_flatten = []
        lvl_pos_embed_flatten = []
        spatial_shapes = []
        for lvl, (feat, mask, pos_embed) in enumerate(
                zip(mlvl_feats, mlvl_masks, mlvl_pos_embeds)):
            bs, c, h, w = feat.shape
            # pos_embed.shape = [2, 256, 128, 128]
            spatial_shape = (h, w)
            spatial_shapes.append(spatial_shape)
            # [bs, w*h, c]
            feat = feat.flatten(2).transpose(1, 2)
            # [bs, w*h]
            mask = mask.flatten(1)
            # [bs, w*h]
            pos_embed = pos_embed.flatten(2).transpose(1, 2)
            lvl_pos_embed = pos_embed + self.level_embeds[lvl].view(1, 1, -1)
            lvl_pos_embed_flatten.append(lvl_pos_embed)
            feat_flatten.append(feat)
            mask_flatten.append(mask)
        feat_flatten = torch.cat(feat_flatten, 1)
        mask_flatten = torch.cat(mask_flatten, 1)
        lvl_pos_embed_flatten = torch.cat(lvl_pos_embed_flatten, 1)
        spatial_shapes = torch.as_tensor(spatial_shapes, dtype=torch.long, device=feat_flatten.device)
        level_start_index = torch.cat((spatial_shapes.new_zeros((1,)), spatial_shapes.prod(1).cumsum(0)[:-1]))
        valid_ratios = torch.stack([self.get_valid_ratio(m) for m in mlvl_masks], 1)

        reference_points = self.get_reference_points(spatial_shapes, valid_ratios, device=feat.device)
        feat_flatten = feat_flatten.permute(1, 0, 2)  # (H*W, bs, embed_dims)
        lvl_pos_embed_flatten = lvl_pos_embed_flatten.permute(1, 0, 2)  # (H*W, bs, embed_dims)
        return feat_flatten, lvl_pos_embed_flatten, mask_flatten, spatial_shapes, reference_points, level_start_index, valid_ratios

    def forward_train(self,
                      img,
                      img_metas,
                      gt_bboxes,
                      gt_labels,
                      gt_bboxes_ignore=None,
                      gt_masks=None,
                      proposals=None,
                      **kwargs):
        """
        Args:
            img (Tensor): of shape (N, C, H, W) encoding input images.
                Typically these should be mean centered and std scaled.

            img_metas (list[dict]): list of image info dict where each dict
                has: 'img_shape', 'scale_factor', 'flip', and may also contain
                'filename', 'ori_shape', 'pad_shape', and 'img_norm_cfg'.
                For details on the values of these keys see
                `mmdet/datasets/pipelines/formatting.py:Collect`.

            gt_bboxes (list[Tensor]): Ground truth bboxes for each image with
                shape (num_gts, 5) in [cx, cy, w, h, a] format.

            gt_labels (list[Tensor]): class indices corresponding to each box

            gt_bboxes_ignore (None | list[Tensor]): specify which bounding
                boxes can be ignored when computing the loss.

            gt_masks (None | Tensor) : true segmentation masks for each box
                used if the architecture supports a segmentation task.

            proposals : override rpn proposals with custom proposals. Use when
                `with_rpn` is False.

        Returns:
            dict[str, Tensor]: a dictionary of loss components
        """
        losses = dict()

        dsa_image = img[:, 3:-4, :, :]
        gt_mask = img[:, -1, :, :]
        gt_mask = torch.where(gt_mask > 0, torch.tensor(1).cuda(), torch.tensor(0).cuda())

        feats = tuple()
        num_frame = dsa_image.shape[1]
        for i in range(num_frame):
            cur_frame = dsa_image[:, i, :, :]
            cur_mask = self.segment(cur_frame.unsqueeze(1).repeat(1, 3, 1, 1))
            input = torch.cat((cur_frame.unsqueeze(1).repeat(1, 2, 1, 1), cur_mask[:, 1, :, :].unsqueeze(1)), dim=1)
            x = self.extract_feat(input)

            feats = feats + x
            if i == int(num_frame / 2):
                segment_loss = self.segment.loss(cur_mask, gt_mask)
                segment_loss['segment_loss'] *= 0.5
                losses.update(segment_loss)
                key_frame_x = x

        mlvl_masks, mlvl_positional_encodings = self.prepare_mask_positional_encoding(feats, img_metas)
        feat_flatten, lvl_pos_embed_flatten, mask_flatten, spatial_shapes, \
            reference_points, level_start_index, valid_ratios = \
            self.get_other_info_for_encoder(feats, mlvl_masks, mlvl_positional_encodings)

        memory = self.encoder(
            query=feat_flatten,
            key=None,
            value=None,
            query_pos=lvl_pos_embed_flatten,
            query_key_padding_mask=mask_flatten,
            spatial_shapes=spatial_shapes,
            reference_points=reference_points,
            level_start_index=level_start_index,
            valid_ratios=valid_ratios,
            **kwargs)

        fused_feats = []
        for idx in range(8, 12):
            feat = memory[level_start_index[idx]:level_start_index[idx + 1]].permute(1, 2, 0)
            feat = feat.view(1, 256, 2 ** (15 - idx), 2 ** (15 - idx))
            feat = feat + key_frame_x[idx - 8]
            fused_feats.append(feat)
        fused_feats = tuple(fused_feats)

        # RPN forward and loss
        if self.with_rpn:
            proposal_cfg = self.train_cfg.get('rpn_proposal', self.test_cfg.rpn)
            rpn_losses, proposal_list = self.rpn_head.forward_train(
                fused_feats,
                img_metas,
                gt_bboxes,
                gt_labels=None,
                gt_bboxes_ignore=gt_bboxes_ignore,
                proposal_cfg=proposal_cfg,
                **kwargs)
            # 默认情况下，proposal_list 长度为4，每个都为[2000, 6]大小的tensor
            losses.update(rpn_losses)
        else:
            proposal_list = proposals

        roi_losses = self.roi_head.forward_train(fused_feats, img_metas, proposal_list,
                                                 gt_bboxes, gt_labels,
                                                 gt_bboxes_ignore, gt_masks,
                                                 **kwargs)
        losses.update(roi_losses)
        return losses

    async def async_simple_test(self,
                                img,
                                img_meta,
                                proposals=None,
                                rescale=False):
        """Async test without augmentation."""
        assert self.with_bbox, 'Bbox head must be implemented.'
        x = self.extract_feat(img)

        if proposals is None:
            proposal_list = await self.rpn_head.async_simple_test_rpn(
                x, img_meta)
        else:
            proposal_list = proposals

        return await self.roi_head.async_simple_test(
            x, proposal_list, img_meta, rescale=rescale)

    def show_segmentation(self, pred_mask):
        pred_mask = pred_mask[0, 1, :, :].cpu()
        pred_mask = np.asarray(pred_mask)
        pred_mask = (pred_mask * 255).astype(np.uint8)
        pred_mask = Image.fromarray(pred_mask)
        pred_mask.show()

    def simple_test_single(self, img, img_metas, proposals=None, rescale=False):
        """Test without augmentation."""
        assert self.with_bbox, 'Bbox head must be implemented.'
        dsa_image = img[:, 5, :, :].unsqueeze(1)
        cur_mask = self.segment(dsa_image.repeat(1, 3, 1, 1))
        input = torch.cat((img[:, 5, :, :].unsqueeze(1).repeat(1, 2, 1, 1), cur_mask[:, 1, :, :].unsqueeze(1)), dim=1)
        x = self.extract_feat(input)

        if proposals is None:
            proposal_list = self.rpn_head.simple_test_rpn(x, img_metas)
        else:
            proposal_list = proposals

        return self.roi_head.simple_test(
            x, proposal_list, img_metas, rescale=rescale)

    def simple_test(self, img, img_metas, proposals=None, rescale=False):
        """Test without augmentation."""
        assert self.with_bbox, 'Bbox head must be implemented.'
        dsa_image = img[:, 3:-4, :, :]

        feats = tuple()
        num_frame = dsa_image.shape[1]
        for i in range(num_frame):
            cur_frame = dsa_image[:, i, :, :]
            cur_mask = self.segment(cur_frame.unsqueeze(1).repeat(1, 3, 1, 1))
            input = torch.cat((cur_frame.unsqueeze(1).repeat(1, 2, 1, 1), cur_mask[:, 1, :, :].unsqueeze(1)), dim=1)
            x = self.extract_feat(input)
            feats = feats + x

        mlvl_masks, mlvl_positional_encodings = self.prepare_mask_positional_encoding(feats, img_metas)
        feat_flatten, lvl_pos_embed_flatten, mask_flatten, spatial_shapes, \
            reference_points, level_start_index, valid_ratios = \
            self.get_other_info_for_encoder(feats, mlvl_masks, mlvl_positional_encodings)

        memory = self.encoder(
            query=feat_flatten,
            key=None,
            value=None,
            query_pos=lvl_pos_embed_flatten,
            query_key_padding_mask=mask_flatten,
            spatial_shapes=spatial_shapes,
            reference_points=reference_points,
            level_start_index=level_start_index,
            valid_ratios=valid_ratios)

        fused_feats = []
        for idx in range(8, 12):
            feat = memory[level_start_index[idx]:level_start_index[idx + 1]].permute(1, 2, 0)
            feat = feat.view(1, 256, 2 ** (15 - idx), 2 ** (15 - idx))
            fused_feats.append(feat)
        fused_feats = tuple(fused_feats)

        if proposals is None:
            proposal_list = self.rpn_head.simple_test_rpn(fused_feats, img_metas)
        else:
            proposal_list = proposals

        return self.roi_head.simple_test(
            feats, proposal_list, img_metas, rescale=rescale)

    def aug_test(self, imgs, img_metas, rescale=False):
        """Test with augmentations.

        If rescale is False, then returned bboxes and masks will fit the scale
        of imgs[0].
        """
        x = self.extract_feats(imgs)
        proposal_list = self.rpn_head.aug_test_rpn(x, img_metas)
        return self.roi_head.aug_test(
            x, proposal_list, img_metas, rescale=rescale)
